from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from .models import Subscription
from django.contrib.auth.decorators import login_required

def subscribe(request):
    if request.user.is_authenticated:
        Subscription.objects.get_or_create(user=request.user, defaults={'email': request.user.email})
        return redirect('subscription_success')
    else:
        return redirect('login')

def subscription_success(request):
    return render(request, 'subscription_success.html')

@login_required
def unsubscribe(request):
    if request.method == 'POST':
        subscription = Subscription.objects.get(user=request.user)
        subscription.subscribed = False
        subscription.save()
        return redirect('unsubscription_success')
    return render(request, 'unsubscribe.html')

def send_newsletter(request):
    if request.method == 'POST':
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        recipients = Subscription.objects.filter(subscribed=True).values_list('email', flat=True)
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, recipients)
        return redirect('newsletter_success')
    return render(request, 'send_newsletter.html')

def unsubscription_success(request):
    return render(request, 'unsubscription_success.html')
