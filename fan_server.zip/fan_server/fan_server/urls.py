from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from users.views import register, confirm_email, delete_user
from ads.views import create_ad, delete_ad, ad_detail, create_response, category_list, category_ads, add_comment, edit_comment, delete_comment, toggle_like
from newsletter.views import subscribe, send_newsletter, subscription_success, unsubscribe, unsubscription_success

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/login/'), name='logout'),
    path('confirm/<int:user_id>/', confirm_email, name='confirm_email'),
    path('delete_user/<int:user_id>/', delete_user, name='delete_user'),
    path('subscription_success/', subscription_success, name='subscription_success'),
    path('unsubscription_success/', unsubscription_success, name='unsubscription_success'),
    path('ads/create/', create_ad, name='create_ad'),
    path('ads/<int:ad_id>/', ad_detail, name='ad_detail'),
    path('ads/<int:ad_id>/response/', create_response, name='create_response'),
    path('categories/', category_list, name='category_list'),
    path('categories/<slug:category>/', category_ads, name='category_ads'),
    path('ads/<int:ad_id>/comment/', add_comment, name='add_comment'),
    path('comment/<int:comment_id>/edit/', edit_comment, name='edit_comment'),
    path('comment/<int:comment_id>/delete/', delete_comment, name='delete_comment'),
    path('ads/<int:ad_id>/like/', toggle_like, name='toggle_like'),
    path('ads/delete/<int:ad_id>/', delete_ad, name='delete_ad'),
    path('newsletter/subscribe/', subscribe, name='subscribe'),
    path('newsletter/send/', send_newsletter, name='send_newsletter'),
    path('newsletter/unsubscribe/', unsubscribe, name='unsubscribe'),
    path('', auth_views.LoginView.as_view(template_name='registration/login.html'), name='home'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
