import json

from django.conf import settings
from django.core.mail import send_mail
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import AdForm, ResponseForm
from .models import Ad, Response, CATEGORY_CHOICES, Comment, Like
from .forms import CommentForm, EditCommentForm
from django.utils import timezone
from django.views.decorators.http import require_POST


def category_list(request):
    categories = [choice[0] for choice in CATEGORY_CHOICES]
    return render(request, 'ads/category_list.html', {'categories': categories})

@login_required
def create_ad(request):
    if request.method == 'POST':
        form = AdForm(request.POST, request.FILES)
        if form.is_valid():
            ad = form.save(commit=False)
            ad.author = request.user
            ad.save()
            return redirect('category_ads', category=ad.category)
    else:
        form = AdForm()
    return render(request, 'ads/create_ad.html', {'form': form})

@login_required
def ad_detail(request, ad_id):
    ad = get_object_or_404(Ad, id=ad_id)
    return render(request, 'ads/ad_detail.html', {'ad': ad})

@login_required
def create_response(request, ad_id):
    ad = get_object_or_404(Ad, id=ad_id)
    if request.method == 'POST':
        form = ResponseForm(request.POST)
        if form.is_valid():
            response = form.save(commit=False)
            response.ad = ad
            response.author = request.user
            response.save()
            # Notify ad author
            send_mail(
                'New response to your ad',
                'You have a new response to your ad.',
                settings.DEFAULT_FROM_EMAIL,
                [ad.author.email],
                fail_silently=False,
            )
            return redirect('ad_detail', ad_id=ad.id)
    else:
        form = ResponseForm()
    return render(request, 'ads/create_response.html', {'form': form})


def category_list(request):
    categories = CATEGORY_CHOICES
    return render(request, 'ads/category_list.html', {'categories': categories})

def category_ads(request, category):
    ads = Ad.objects.filter(category=category)
    return render(request, 'ads/category_ads.html', {'ads': ads, 'category': category})


@login_required
def add_comment(request, ad_id):
    ad = get_object_or_404(Ad, id=ad_id)
    if request.method == 'POST':
        form = CommentForm(request.POST, request.FILES)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.ad = ad
            comment.author = request.user
            comment.save()

            # Send email notification to ad author
            if ad.author.email and ad.author != request.user:  # Проверяем, что автор объявления не является автором комментария
                send_mail(
                    'New comment on your ad',
                    f'You have a new comment on your ad "{ad.title}".',
                    settings.DEFAULT_FROM_EMAIL,
                    [ad.author.email],
                    fail_silently=False,
                )

            return redirect('category_ads', category=ad.category)
    else:
        form = CommentForm()
    return render(request, 'ads/add_comment.html', {'form': form, 'ad': ad})


@login_required
@require_POST
def edit_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.author != request.user or timezone.now() > comment.created_at + timezone.timedelta(hours=1):
        return JsonResponse({'success': False, 'error': 'Permission denied.'})

    form = EditCommentForm(request.POST, request.FILES, instance=comment)
    if form.is_valid():
        form.save()
        response_data = {
            'success': True,
            'author': comment.author.username,
            'content': comment.content,
        }
        if comment.image:
            response_data['image'] = comment.image.url
        if comment.video:
            response_data['video'] = comment.video.url
        return JsonResponse(response_data)
    else:
        return JsonResponse({'success': False, 'error': 'Invalid form.'})

@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.author == request.user:
        comment.delete()
    return redirect('category_ads', category=comment.ad.category)


@login_required
def toggle_like(request, ad_id):
    ad = get_object_or_404(Ad, id=ad_id)
    like = Like.objects.filter(ad=ad, user=request.user).first()
    if like:
        like.delete()
    else:
        Like.objects.create(ad=ad, user=request.user)
    return redirect('category_ads', category=ad.category)

@login_required
def delete_ad(request, ad_id):
    ad = get_object_or_404(Ad, id=ad_id)
    if ad.author == request.user:
        ad.delete()
    return redirect('category_ads', category=ad.category)